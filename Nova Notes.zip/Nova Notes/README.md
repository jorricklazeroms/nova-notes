# Nova Notes v0.1

Nova Notes is a local-first, offline-first PWA for knowledge management inspired by Apple Notes and Obsidian. The app stores Markdown notes in IndexedDB, creates revision snapshots on each save, and supports wiki-style links for future graph features.

## Architecture

- UI: HTML + Tailwind utility CSS + minimal custom CSS.
- Data layer: IndexedDB with object stores for `notes`, `revisions`, and `config`.
- Rendering: Lightweight Markdown parsing for headings, lists, code blocks, links, images, and WikiLinks.
- PWA: Service worker caches the app shell for offline use.

## Offline-First Design

- All edits are saved locally immediately using IndexedDB.
- The app loads without a network connection via the service worker cache.
- Sync is optional and user-owned. The app stores a repo URL and token placeholder locally without hardcoding credentials.
- Conflicts are resolved manually via the revision history (no auto-merge in v0.1).

## GitHub Sync Concept

- User links a repository in the app settings.
- Sync is manual (push/pull) and out of scope for v0.1.
- Token handling is a placeholder only and should be replaced with secure OAuth or device-bound tokens before production.

## Files

- `index.html`: UI and app logic.
- `manifest.json`: PWA manifest.
- `sw.js`: Service worker for offline caching.

## Notes on Icons

Add `icon-192.png` and `icon-512.png` to the project root to complete the PWA install experience.
